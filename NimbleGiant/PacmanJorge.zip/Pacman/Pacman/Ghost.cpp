#include "Ghost.h"
#include "World.h"
#include "MapTile.h"
#include "Drawer.h"
#include "Avatar.h"
#include "Pacman.h"
#include "GlobalEnums.h"

#include <iostream>

Ghost::Ghost(const Vector2f& aPosition, Sprite* entitySprite, GhostName Name) : MovableGameEntity(aPosition, entitySprite)
{
	sprite->SetFrame(Ghost_Normal);

	Speed = RegularSpeed;

	this->Name = Name;

	CurrentState = Spawning;
}

void Ghost::SetCurrentState(State GlobalState)
{	
	// If CurrentState is eaten, the global state may change but the ghost needs to do its respawn cycle.
	// To handle this type of cases is why this function exists.
	if (CurrentState == Eaten)
	{
		return;
	}
	else
	{
		CurrentState = GlobalState;
	}
}

void Ghost::UpdateBlinky(World* aWorld, Avatar* avatar, State GlobalState)
{
	// Handle special cases here
	SetCurrentState(GlobalState);

	switch (CurrentState)
	{
		case Scatter:
		{
			SetTexture(Ghost_Normal);
			// Blinky scatter is on top right corner of the map. Outside of the playable/wall area
			ChooseNextTile(aWorld, 26, -1);
		} break;
		case Chase:
		{
			// Blinky's target is always the player
			SetTexture(Ghost_Normal);
			ChooseNextTile(aWorld, avatar->GetCurrentTileX(), avatar->GetCurrentTileY());
		} break;
		case Frightened:
		{
			SetTexture(Ghost_Frightened);
			if(IsAtDestination())
				ChooseRandomTile(aWorld);
		} break;
		case Eaten:
		{
			SetTexture(Ghost_Eaten);
			Speed = EatenSpeed;

			if(myCurrentTileX != 12 || myCurrentTileY != 13)
				ChooseNextTile(aWorld, 12, 13); // 12, 13 is inside the ghost pen

			if (GlobalState != Frightened && myCurrentTileX == 12 && myCurrentTileY == 13)
			{
				Speed = RegularSpeed;
				CurrentState = GlobalState;
			}
		} break;
		case Spawning:
		{
			// CurrentState = Chase;
		} break;
	}
}

void Ghost::UpdatePinky(World* aWorld, Avatar* avatar, State GlobalState)
{
	SetCurrentState(GlobalState);

	switch (CurrentState)
	{
		case Scatter:
		{
			SetTexture(Ghost_Normal);
			// Pinky scatter is on the top left corner of the map. Outside of the playable/wall area
			ChooseNextTile(aWorld, -1, -1);
		} break;
		case Chase:
		{
			// Pinky's chase mode is:
			// If pacman is facing left, down or right. The target is 4 tiles ahead of pacman's position
			// In the direction where pacman is facing
			// If pacman is facing up, the target direction is 4 up and 4 to the left
			SetTexture(Ghost_Normal);
			Direction FacingDirection = avatar->GetFacingDirection();
			if (FacingDirection == Up)
			{
				ChooseNextTile(aWorld, avatar->GetCurrentTileX() - 4, avatar->GetCurrentTileY() - 4);
			}
			else
			{
				if (FacingDirection == Left)
				{
					ChooseNextTile(aWorld, avatar->GetCurrentTileX() - 4, avatar->GetCurrentTileY());
				}
				else if (FacingDirection == Right)
				{
					ChooseNextTile(aWorld, avatar->GetCurrentTileX() + 4, avatar->GetCurrentTileY());
				}
				else if (FacingDirection == Down)
				{
					ChooseNextTile(aWorld, avatar->GetCurrentTileX(), avatar->GetCurrentTileY() + 4);
				}
			}
		} break;
		case Frightened:
		{
			// TODO: Since Frightened state is the same for all ghosts, make a function
			SetTexture(Ghost_Frightened);
			if (IsAtDestination())
				ChooseRandomTile(aWorld);
		} break;
		case Eaten:
		{
			// TODO: Since Eatened state is the same for all ghosts, make a function
			SetTexture(Ghost_Eaten);
			Speed = EatenSpeed;

			if (myCurrentTileX != 12 || myCurrentTileY != 13)
				ChooseNextTile(aWorld, 12, 13); // 12, 13 is inside the ghost pen

			if (GlobalState != Frightened && myCurrentTileX == 12 && myCurrentTileY == 13)
			{
				Speed = RegularSpeed;
				CurrentState = GlobalState;
			}
		} break;
		case Spawning:
		{
			SetTexture(Ghost_Normal);
			ChooseNextTile(aWorld, 13, 10);
		} break;
	}
}

void Ghost::UpdateInky(World* aWorld, Avatar* avatar, State GlobalState, Pacman *pacman)
{
	SetCurrentState(GlobalState);

	switch (CurrentState)
	{
		case Scatter:
		{
			SetTexture(Ghost_Normal);
			// Inky scatter is on the bottom right corner of the map. Outside of the playable/wall area
			ChooseNextTile(aWorld, 26, 30);
		} break;
		case Chase:
		{
			// Inky's chase mode is:
			// Find the tile 2 tiles in front of pacman position according to it's direction.
			// If pacman is facing up, the first target tile is two in front and two to the left. This is the Intermediate Target.
			// Now  take that intermediate target tile, get the vector from that tile to blinky's position
			// rotate it 180�, that's the target tile.

			SetTexture(Ghost_Normal);
			Direction FacingDirection = avatar->GetFacingDirection();
			int IntermediateTargetX;
			int IntermediateTargetY;
			if (FacingDirection == Up)
			{
				IntermediateTargetX = avatar->GetCurrentTileX() - 2;
				IntermediateTargetY = avatar->GetCurrentTileY() - 2;
			}
			else
			{
				if (FacingDirection == Left)
				{
					IntermediateTargetX = avatar->GetCurrentTileX() - 2;
					IntermediateTargetY = avatar->GetCurrentTileY();
				}
				else if (FacingDirection == Right)
				{
					IntermediateTargetX = avatar->GetCurrentTileX() + 2;
					IntermediateTargetY = avatar->GetCurrentTileY();
				}
				else if (FacingDirection == Down)
				{
					IntermediateTargetX = avatar->GetCurrentTileX();
					IntermediateTargetY = avatar->GetCurrentTileY() + 2;
				}
			}

			// Get Blinky's current tile
			int BlinkyX = pacman->GetBlinkyCurrentX();
			int BlinkyY = pacman->GetBlinkyCurrentY();

			// Get vector from avatar to blinky, rotate it 180 degrees
			int TargetX = -(avatar->GetCurrentTileX() - BlinkyX);
			int TargetY = -(avatar->GetCurrentTileY() - BlinkyY);

			ChooseNextTile(aWorld, TargetX, TargetY);

		} break;
		case Frightened:
		{
			// TODO: Since Frightened state is the same for all ghosts, make a function
			SetTexture(Ghost_Frightened);
			if (IsAtDestination())
				ChooseRandomTile(aWorld);
		} break;
		case Eaten:
		{
			// TODO: Since Eatened state is the same for all ghosts, make a function
			SetTexture(Ghost_Eaten);
			Speed = EatenSpeed;

			if (myCurrentTileX != 12 || myCurrentTileY != 13)
				ChooseNextTile(aWorld, 12, 13); // 12, 13 is inside the ghost pen

			if (GlobalState != Frightened && myCurrentTileX == 12 && myCurrentTileY == 13)
			{
				Speed = RegularSpeed;
				CurrentState = GlobalState;
			}
		} break;
		case Spawning:
		{
			SetTexture(Ghost_Normal);
			ChooseNextTile(aWorld, 13, 10);
		} break;
	}
}

void Ghost::UpdateClyde(World* aWorld, Avatar* avatar, State GlobalState)
{
	// Handle special cases here
	SetCurrentState(GlobalState);

	switch (CurrentState)
	{
		case Scatter:
		{
			SetTexture(Ghost_Normal);
			// Clyde scatter is on the bottom left corner of the map. Outside of the playable/wall area
			const int ScatterTargetX = 0;
			const int ScatterTargetY = 30;
			ChooseNextTile(aWorld, ScatterTargetX, ScatterTargetY);
		} break;
		case Chase:
		{
			// Clyde's chase mode is:
			// If Clyde is farther than 8 tiles from pacman, target is pacman
			// if Clyde is closer than 8 tiles from pacman, target is the same as scatter. 0, 30
			SetTexture(Ghost_Normal);
			float Distance = DistanceFromAvatar(avatar);
			if (Distance > 8)
			{
				ChooseNextTile(aWorld, avatar->GetCurrentTileX(), avatar->GetCurrentTileY());
			}
			else
			{
				ChooseNextTile(aWorld, 0, 30);
			}
		} break;
		case Frightened:
		{
			SetTexture(Ghost_Frightened);
			if (IsAtDestination())
				ChooseRandomTile(aWorld);
		} break;
		case Eaten:
		{
			SetTexture(Ghost_Eaten);
			Speed = EatenSpeed;

			if (myCurrentTileX != 12 || myCurrentTileY != 13)
				ChooseNextTile(aWorld, 12, 13); // 12, 13 is inside the ghost pen

			if (GlobalState != Frightened && myCurrentTileX == 12 && myCurrentTileY == 13)
			{
				Speed = RegularSpeed;
				CurrentState = GlobalState;
			}
		} break;
		case Spawning:
		{
			SetTexture(Ghost_Normal);
			ChooseNextTile(aWorld, 13, 10);
		} break;
	}
}

void Ghost::Update(float aTime, World* aWorld, Avatar* avatar, State GlobalState, Pacman *pacman)
{
	switch (Name)
	{
		case Blinky:
		{
			UpdateBlinky(aWorld, avatar, GlobalState);
		} break;
		case Pinky:
		{
			UpdatePinky(aWorld, avatar, GlobalState);
		} break;
		case Inky:
		{
			UpdateInky(aWorld, avatar, GlobalState, pacman);
		} break;
		case Clyde:
		{
			UpdateClyde(aWorld, avatar, GlobalState);
		} break;
		default:
		{
			std::cout << "switch(GhostName) hit default case. This is invalid code please fix." << std::endl;
		} break;
	}

	int tileSize = 22;
	Vector2f destination(myNextTileX * tileSize, myNextTileY * tileSize);
	Vector2f direction = destination - myPosition;

	float distanceToMove = aTime * Speed;

	if (distanceToMove > direction.Length())
	{
		myPosition = destination;

		myPreviousTileX = myCurrentTileX;
		myPreviousTileY = myCurrentTileY;

		myCurrentTileX = myNextTileX;
		myCurrentTileY = myNextTileY;
	}
	else
	{
		direction.Normalize();
		myPosition += direction * distanceToMove;
	}
}

void Ghost::ChooseNextTile(World *World, int TargetX, int TargetY)
{
	if (IsAtDestination())
	{
		int ShortestDistance = INT_MAX;

		// Right
		int RightX = myCurrentTileX + 1;
		int RightY = myCurrentTileY;
		if (World->TileIsValid(RightX, RightY) && RightX != myPreviousTileX)
		{
			int X = TargetX - RightX;
			int Y = TargetY - RightY;
			int DistanceSquared = X * X + Y * Y;
			if (DistanceSquared <= ShortestDistance)
			{
				ShortestDistance = DistanceSquared;
				myNextTileX = RightX;
				myNextTileY = RightY;
			}
		}

		// Down
		int DownX = myCurrentTileX;
		int DownY = myCurrentTileY + 1;
		if (World->TileIsValid(DownX, DownY) && DownY != myPreviousTileY)
		{
			int X = TargetX - DownX;
			int Y = TargetY - DownY;
			int DistanceSquared = X * X + Y * Y;
			if (DistanceSquared <= ShortestDistance)
			{
				ShortestDistance = DistanceSquared;
				myNextTileX = DownX;
				myNextTileY = DownY;
			}
		}

		// Left
		int LeftX = myCurrentTileX - 1;
		int LeftY = myCurrentTileY;
		if (World->TileIsValid(LeftX, LeftY) && LeftX != myPreviousTileX)
		{
			int X = TargetX - LeftX;
			int Y = TargetY - LeftY;
			int DistanceSquared = X * X + Y * Y;
			if (DistanceSquared <= ShortestDistance)
			{
				ShortestDistance = DistanceSquared;
				myNextTileX = LeftX;
				myNextTileY = LeftY;
			}
		}

		// Up
		int UpX = myCurrentTileX;
		int UpY = myCurrentTileY - 1;
		if (World->TileIsValid(UpX, UpY) && UpY != myPreviousTileY)
		{
			int X = TargetX - UpX;
			int Y = TargetY - UpY;
			int DistanceSquared = X * X + Y * Y;
			if (DistanceSquared <= ShortestDistance)
			{
				ShortestDistance = DistanceSquared;
				myNextTileX = UpX;
				myNextTileY = UpY;
			}
		}
	}
}

void Ghost::ChooseRandomTile(World* aWorld)
{
	// Chooses a random valid tile that is not behind the ghost
	Direction RandomDirection;

	while (1)
	{
		RandomDirection = (Direction)(rand() % 4);
		if (DirectionIsValid(aWorld, RandomDirection) && NotPreviousDirection(RandomDirection))
			break;
	}

	switch (RandomDirection)
	{
		case Up:
		{
			myNextTileX = myCurrentTileX;
			myNextTileY = myCurrentTileY - 1;
		} break;
		case Down:
		{
			myNextTileX = myCurrentTileX;
			myNextTileY = myCurrentTileY + 1;
		} break;
		case Left:
		{
			myNextTileX = myCurrentTileX - 1;
			myNextTileY = myCurrentTileY;
			break;
		}
		case Right:
		{
			myNextTileX = myCurrentTileX + 1;
			myNextTileY = myCurrentTileY;
		} break;
	}
}

void Ghost::SetTexture(ImageIdentifier Id)
{
	sprite->SetFrame(Id);
}

bool Ghost::DirectionIsValid(World* aWorld, Direction DirectionInput)
{
	int X = myCurrentTileX;
	int Y = myCurrentTileY;
	switch (DirectionInput)
	{
		case Up:
		{
			Y -= 1;
			return aWorld->TileIsValid(X, Y);
		} break;
		case Left:
		{
			X -= 1;
			return aWorld->TileIsValid(X, Y);
		} break;
		case Down:
		{
			Y += 1;
			return aWorld->TileIsValid(X, Y);
		} break;
		case Right:
		{
			X += 1;
			return aWorld->TileIsValid(X, Y);
		} break;
	}
}

bool Ghost::NotPreviousDirection(Direction Input)
{
	int TileX = myCurrentTileX;
	int TileY = myCurrentTileY;

	switch (Input)
	{
		case Up:
		{
			TileY -= 1;
		} break;
		case Down:
		{
			TileY += 1;
		} break;
		case Left:
		{
			TileX -= 1;
		} break;
		case Right:
		{
			TileX += 1;
		} break;
	}

	if (TileX != myPreviousTileX || TileY != myPreviousTileY)
		return true;
	else
		return false;
}

float Ghost::DistanceFromAvatar(Avatar* avatar)
{
	float Result = 0.0f;

	float DeltaX = myCurrentTileX - avatar->GetCurrentTileX();
	float DeltaY = myCurrentTileY - avatar->GetCurrentTileY();

	Result = sqrtf(DeltaX * DeltaX + DeltaY * DeltaY);

	return Result;
}
