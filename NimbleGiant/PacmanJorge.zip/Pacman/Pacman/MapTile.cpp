#include "MapTile.h"

MapTile::MapTile(int anX, int anY) : X(anX), Y(anY) { }
