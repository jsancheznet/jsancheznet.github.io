#include "World.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

#include "MapTile.h"
#include "Dot.h"
#include "BigDot.h"
#include "Drawer.h"
#include "GlobalEnums.h"

// TODO: Create member variables for map width and height in tiles, replace every magic number used for these.

void World::Init(Drawer* gameDrawer)
{
	boardBackground = new Sprite;
	boardBackground->AddTexture(gameDrawer, "playfield.png", Game_Background);
	boardBackground->SetSize(1024, 768);
	boardBackground->SetFrame(Game_Background);

	InitMap(gameDrawer);
}

bool World::InitMap(Drawer* gameDrawer)
{
	std::string line;
	std::ifstream myfile ("map.txt");

	// Create sprites to hold bigdots and smalldots so each dot instance can reuse the sprite.
	DotSprite = new Sprite;
	DotSprite->AddTexture(gameDrawer, "small_dot_32.png", Game_SmallDot);
	DotSprite->SetSize(32, 32);
	BigDotSprite = new Sprite;
	BigDotSprite->AddTexture(gameDrawer, "big_dot_32.png", Game_BigDot);
	BigDotSprite->SetSize(32, 32);

	if (myfile.is_open())
	{
		int lineIndex = 0;
		while (! myfile.eof() )
		{
			std::getline (myfile,line);
			for (int i = 0; i < line.length(); i++)
			{
				if (line[i] != 'x')
				{
					MapTile ValidTile = { i, lineIndex };
					ValidTiles.push_back(ValidTile);

					if (line[i] == '.')
					{
						Dot* dot = new Dot(Vector2f(i * 22, lineIndex * 22), DotSprite);
						myDots.push_back(dot);
					}
					else if (line[i] == 'o')
					{
						BigDot* dot = new BigDot(Vector2f(i * 22, lineIndex * 22), BigDotSprite);
						myBigDots.push_back(dot);
					}
				}
			}

			lineIndex++;
		}
		myfile.close();
	}

	return true;
}

void World::Draw(Drawer* aDrawer)
{
	boardBackground->Draw(aDrawer, 0, 0);

	for(std::list<Dot*>::iterator list_iter = myDots.begin(); list_iter != myDots.end(); list_iter++)
	{
		Dot* dot = *list_iter;
		dot->Draw(aDrawer);
	}

	for(std::list<BigDot*>::iterator list_iter = myBigDots.begin(); list_iter != myBigDots.end(); list_iter++)
	{
		BigDot* dot = *list_iter;
		dot->Draw(aDrawer);
	}
}

bool World::TileIsValid(int anX, int anY)
{
	for(std::vector<MapTile>::iterator iterator = ValidTiles.begin(); 
		iterator != ValidTiles.end();
		iterator++)
	{
		MapTile Tile = *iterator;

		if (anX == Tile.X && anY == Tile.Y)
			return true;
	}

	// TODO: We can probably implement teleportation here by treating the sides as valid tiles
	// if (anX == -1 && anY == 13)
	//	return true;

	return false;
}

int  World::GetDotCount()
{
	return myDots.size() + myBigDots.size();
}

bool World::HasIntersectedDot(const Vector2f& aPosition)
{
	for(std::list<Dot*>::iterator list_iter = myDots.begin(); list_iter != myDots.end(); list_iter++)
	{
		Dot* dot = *list_iter;
		if ((dot->GetPosition() - aPosition).Length() < 5.f)
		{
			myDots.remove(dot);
			delete dot;
			return true;
		}
	}

	return false;
}

bool World::HasIntersectedBigDot(const Vector2f& aPosition)
{
	for(std::list<BigDot*>::iterator list_iter = myBigDots.begin(); list_iter != myBigDots.end(); list_iter++)
	{
		BigDot* dot = *list_iter;
		if ((dot->GetPosition() - aPosition).Length() < 5.f)
		{
			myBigDots.remove(dot);
			delete dot;
			return true;
		}
	}

	return false;
}

bool World::HasIntersectedCherry(const Vector2f& aPosition)
{
	return true;
}