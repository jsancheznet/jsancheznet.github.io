#ifndef PACMAN_H
#define PACMAN_H

#include "Vector2f.h"
#include "GlobalEnums.h"
#include <list>
#include <vector>
#include "Ghost.h"

struct SDL_Surface;
class Drawer;
class Avatar;
class World;
class Ghost;
class SpriteFont;

class Pacman
{
public:
	static Pacman* Create(Drawer* aDrawer);

	void ProcessEventQueue(bool* running);
	bool Update(float aTime);
	bool Draw();

	int GetBlinkyCurrentX();
	int GetBlinkyCurrentY();

	State GlobalState;

private:
	Pacman(Drawer* aDrawer);
	bool Init();
	bool UpdateInput();
	void MoveAvatar();
	bool CheckEndGameCondition();

	bool TimerBetween(float, float);
	void SetGlobalState();
	void ResetGhosts();
	void ResetLevel();

	void UpdateScore();
	void UpdateLives();
	void SetFPS(int fps);


	Drawer* myDrawer;

	int Lives;
	int Score;
	int Fps;

	float Timer;
	float FrightenedTimer;

	// TODO: This should probably go in the Avatar class
	Vector2f DesiredDirection;
	Vector2f myNextMovement;

	Avatar*            myAvatar;
	std::list<Ghost*>  ghosts;
	World*             myWorld;

	SpriteFont* gameplayMessage;
	SpriteFont* scoreDisplay;
	SpriteFont* livesDisplay;
	SpriteFont* fpsDisplay;
};

#endif // PACMAN_H