#ifndef MOVABLEGAMEENTITY_H
#define MOVABLEGAMEENTITY_H

#include "GameEntity.h"
#include "Vector2f.h"

class MovableGameEntity : public GameEntity
{
public:

	MovableGameEntity(const Vector2f& aPosition, Sprite* entitySprite);

	void Respawn(const Vector2f& aPosition);

	void SetNextTile(int anX, int anY);
	int GetCurrentTileX() const { return myCurrentTileX; }
	int GetCurrentTileY() const { return myCurrentTileY; }

	bool IsAtDestination();

protected:

	// TODO: Implement integer vectors to simplify this
	int myCurrentTileX;
	int myCurrentTileY;

	int myNextTileX;
	int myNextTileY;

	int myPreviousTileX;
	int myPreviousTileY;
};

#endif // MOVABLEGAMEENTITY_H