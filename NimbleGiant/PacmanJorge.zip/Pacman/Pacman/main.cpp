#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include "assert.h"
#include "pacman.h"
#include "drawer.h"
#include <iostream>

int main(int argc, char **argv)
{
	if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		assert(0 && "Failed to initialize video!");
		exit(-1);
	}
	
	SDL_Window* window = SDL_CreateWindow("Pacman", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1024, 768, SDL_WINDOW_OPENGL); // TODO: SDL_WINDOW_OPENGL do we need that window flag?
	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED /* | SDL_RENDERER_PRESENTVSYNC */);

	if(!window)
	{
		assert(0 && "Failed to create window!");
		exit(-1);
	}

	IMG_Init(IMG_INIT_PNG);

	if (TTF_Init() == -1)
	{
		assert(0 && "Failed to initialize SDL_TTF ttf!");
		exit(-1);
	}

	Drawer* drawer = Drawer::Create(window, renderer);
	Pacman* pacman = Pacman::Create(drawer);

	float lastFrame = (float) SDL_GetTicks() * 0.001f;
	float SecondsElapsed = lastFrame;
	float DeltaTime = 0.0f;

	bool Running = true;
	while(Running)
	{
		float currentFrame = (float)SDL_GetTicks() * 0.001f;
		DeltaTime = currentFrame - lastFrame;
		SecondsElapsed += DeltaTime;

		pacman->ProcessEventQueue(&Running);

		if (!pacman->Update(DeltaTime)) { Running = false; }

		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
		SDL_RenderClear(renderer);
		pacman->Draw();		
		SDL_RenderPresent(renderer);

		lastFrame = currentFrame;
	}

	delete pacman;
	delete drawer;

	TTF_Quit();
	IMG_Quit();
	SDL_Quit( );

	return 0;
}

