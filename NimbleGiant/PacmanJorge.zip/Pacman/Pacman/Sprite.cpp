#include <utility>

#include "Sprite.h"
#include "Drawer.h"
#include "GlobalEnums.h"
#include "SDL_image.h"
#include "SDL_rect.h"
#include "SDL.h"

void Sprite::SetFrame(ImageIdentifier Id)
{
	if (textures[Id] != NULL)
	{
		currentFrame = Id;
	}
}

void Sprite::Draw(Drawer* drawer, int posX, int posY)
{
	drawer->Draw(textures[currentFrame], frame, posX, posY);
}

void Sprite::AddTexture(Drawer *drawer, std::string Filename, ImageIdentifier Key)
{
	SDL_Texture *Texture = IMG_LoadTexture(drawer->GetRenderer(), Filename.c_str());
	textures.insert(std::pair<int, SDL_Texture*>(Key, Texture));
}

void Sprite::SetSize(int Width, int Height)
{
	frame.x = 0;
	frame.y = 0;
	frame.w = Width;
	frame.h = Height;
}
