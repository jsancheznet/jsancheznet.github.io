#include "Pacman.h"
#include "Drawer.h"
#include "SDL.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

#include "Avatar.h"
#include "World.h"
#include "Ghost.h"
#include "SpriteFont.h"
#include "GlobalEnums.h"

Pacman* Pacman::Create(Drawer* aDrawer)
{
	Pacman* pacman = new Pacman(aDrawer);

	if (!pacman->Init())
	{
		delete pacman;
		pacman = NULL;
	}

	return pacman;
}

Pacman::Pacman(Drawer* aDrawer)
: myDrawer(aDrawer)
, myNextMovement(-1.f,0.f)
, Score(0)
, Fps(0)
, Lives(3)
, DesiredDirection(-1.0f, 0.0f)
, Timer(0.0f)
, FrightenedTimer(0.0f)
{
	Sprite* PuckMan = new Sprite;
	PuckMan->SetSize(32, 32);
	PuckMan->AddTexture(myDrawer, "closed_right_32.png", Avatar_Closed_Right);
	PuckMan->AddTexture(myDrawer, "open_right_32.png", Avatar_Open_Right);
	PuckMan->AddTexture(myDrawer, "closed_down_32.png", Avatar_Closed_Down);
	PuckMan->AddTexture(myDrawer, "open_down_32.png", Avatar_Open_Down);
	PuckMan->AddTexture(myDrawer, "closed_left_32.png", Avatar_Closed_Left);
	PuckMan->AddTexture(myDrawer, "open_left_32.png", Avatar_Open_Left);
	PuckMan->AddTexture(myDrawer, "closed_up_32.png", Avatar_Closed_Up);
	PuckMan->AddTexture(myDrawer, "open_up_32.png", Avatar_Open_Up);
	myAvatar = new Avatar(Vector2f(13 * 22, 22 * 22), PuckMan);

	// Blinky
	Sprite *BlinkySprite = new Sprite;
	BlinkySprite->SetSize(32, 32);
	BlinkySprite->AddTexture(myDrawer, "ghost_32_red.png", Ghost_Normal);
	BlinkySprite->AddTexture(myDrawer, "ghost_vulnerable_32.png", Ghost_Frightened);
	BlinkySprite->AddTexture(myDrawer, "ghost_dead_32.png", Ghost_Eaten);
	ghosts.push_back(new Ghost(Vector2f(13 * 22, 10 * 22), BlinkySprite, Ghost::GhostName::Blinky));

	// Inky
	Sprite* InkySprite = new Sprite;
	InkySprite->SetSize(32, 32);
	InkySprite->AddTexture(myDrawer, "ghost_32_cyan.png", Ghost_Normal);
	InkySprite->AddTexture(myDrawer, "ghost_vulnerable_32.png", Ghost_Frightened);
	InkySprite->AddTexture(myDrawer, "ghost_dead_32.png", Ghost_Eaten);
	ghosts.push_back(new Ghost(Vector2f(11 * 22, 13 * 22), InkySprite, Ghost::GhostName::Inky));

	// Pinky
	Sprite* PinkySprite = new Sprite;
	PinkySprite->SetSize(32, 32);
	PinkySprite->AddTexture(myDrawer, "ghost_32_pink.png", Ghost_Normal);
	PinkySprite->AddTexture(myDrawer, "ghost_vulnerable_32.png", Ghost_Frightened);
	PinkySprite->AddTexture(myDrawer, "ghost_dead_32.png", Ghost_Eaten);
	ghosts.push_back(new Ghost(Vector2f(12 * 22, 13 * 22), PinkySprite, Ghost::GhostName::Pinky));

	// Clyde
	Sprite* ClydeSprite = new Sprite;
	ClydeSprite->SetSize(32, 32);
	ClydeSprite->AddTexture(myDrawer, "ghost_32_orange.png", Ghost_Normal);
	ClydeSprite->AddTexture(myDrawer, "ghost_vulnerable_32.png", Ghost_Frightened);
	ClydeSprite->AddTexture(myDrawer, "ghost_dead_32.png", Ghost_Eaten);
	ghosts.push_back(new Ghost(Vector2f(13 * 22, 13 * 22), ClydeSprite, Ghost::GhostName::Clyde));

	myWorld = new World();

	gameplayMessage = SpriteFont::Create("freefont-ttf\\sfd\\FreeMono.ttf", "", { 255,255,255,255 }, 24, myDrawer);
	scoreDisplay = SpriteFont::Create("freefont-ttf\\sfd\\FreeMono.ttf", "", { 0,255,0,255 }, 24, myDrawer);
	livesDisplay = SpriteFont::Create("freefont-ttf\\sfd\\FreeMono.ttf", "", { 255,255,255,255 }, 24, myDrawer);
	fpsDisplay = SpriteFont::Create("freefont-ttf\\sfd\\FreeMono.ttf", "", { 255,255,255,255 }, 24, myDrawer);

	UpdateLives();
	UpdateScore();
}

bool Pacman::Init()
{
	myWorld->Init(myDrawer);

	return true;
}

void Pacman::ProcessEventQueue(bool* running)
{
	SDL_Event Event;
	while (SDL_PollEvent(&Event))
	{
		switch (Event.type)
		{
			case SDL_QUIT:
			{
				*running = false;
				break;
			}
			default:
			{
				break;
			}
		}
	}
}

bool Pacman::TimerBetween(float Low, float High)
{
	if (Timer >= Low && Timer <= High)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Pacman::SetGlobalState()
{
	if (FrightenedTimer > 0.0f)
		return;

	if (TimerBetween(0.0f, 2.0f))
	{
		// Spawn
		GlobalState = Spawning;
	}
	else if (TimerBetween(2.0f, 9.0f))
	{
		// Scatter
		GlobalState = Scatter;
	}
	else if (TimerBetween(9.0f, 29.0f))
	{
		// Chase
		GlobalState = Chase;
	}
	else if (TimerBetween(29.0f, 36.0f))
	{
		// Scatter
		GlobalState = Scatter;
	}
	else if (TimerBetween(36.0f, 56.0f))
	{
		// Chase
		GlobalState = Chase;
	}
	else if (TimerBetween(56.0f, 61.0f))
	{
		// Scatter
		GlobalState = Scatter;
	}
	else if (TimerBetween(61.0f, 81.0f))
	{
		// Chase
		GlobalState = Chase;
	}
	else if (TimerBetween(81.0f, 86.0f))
	{
		// Scatter
		GlobalState = Scatter;
	}
	else
	{
		// Chase forever
		GlobalState = Chase;
	}
}

void Pacman::ResetGhosts()
{
	for (auto& Ghost : ghosts)
	{
		// Blinky Initial Position: 13, 10
		// Inky: 11, 13 
		// Pinky: 12, 13
		// Clyde: 13, 13

		// Oh god, std::list has no random access.
		if (Ghost->Name == Ghost::GhostName::Blinky)
		{
			Ghost->Respawn(Vector2f(13 * 22, 10 * 22));
		}
		else if (Ghost->Name == Ghost::GhostName::Inky)
		{
			Ghost->Respawn(Vector2f(11 * 22, 13 * 22));
		}
		else if (Ghost->Name == Ghost::GhostName::Pinky)
		{
			Ghost->Respawn(Vector2f(12 * 22, 13 * 22));
		}
		else if (Ghost->Name == Ghost::GhostName::Clyde)
		{
			Ghost->Respawn(Vector2f(13 * 22, 13 * 22));
		}
	}
}

void Pacman::ResetLevel()
{
	// This function is only called when pacman gets caught and it has lives left
	// Reset Ghosts
	// Reset Pacman
	// Reset Level
	myAvatar->Respawn(Vector2f(13 * 22, 22 * 22));
	ResetGhosts();
	GlobalState = Spawning;
	Timer = 0.0f;
}

int Pacman::GetBlinkyCurrentX()
{
	for (auto* Ghost : ghosts)
	{
		if (Ghost->Name == Ghost::GhostName::Blinky)
			return Ghost->GetCurrentTileX();
	}

	return NULL;
}

int Pacman::GetBlinkyCurrentY()
{
	for (auto* Ghost : ghosts)
	{
		if (Ghost->Name == Ghost::GhostName::Blinky)
			return Ghost->GetCurrentTileY();
	}

	return NULL;
}

bool Pacman::Update(float aTime)
{
	Timer += aTime;
	if (FrightenedTimer > 0.0f)
	{
		FrightenedTimer -= aTime;
	}
	else
	{
		SetGlobalState();
	}

	if (!UpdateInput())
		return false;

	if (CheckEndGameCondition())
		return true;
	else if (Lives <= 0)
		return true;

	SetGlobalState();

	MoveAvatar();
	myAvatar->Update(aTime);

	// Update ghosts
	for (auto Ghost : ghosts)
	{
		Ghost->Update(aTime, myWorld, myAvatar, GlobalState, this);
	}

	if (myWorld->HasIntersectedDot(myAvatar->GetPosition())) { Score += 10; }
	if (myWorld->HasIntersectedBigDot(myAvatar->GetPosition())) 
	{ 
		Score += 50; 
		GlobalState = Frightened;
		FrightenedTimer = 7.0f;
	}

	if (CheckEndGameCondition()) { gameplayMessage->SetText("You win!"); }

	// Check for player collision
	for (auto Ghost : ghosts)
	{
		if ((Ghost->GetPosition() - myAvatar->GetPosition()).Length() < 16.f)
		{
			if (Ghost->CurrentState == Chase || Ghost->CurrentState == Scatter)
			{
				if (--Lives == 0)
				{
					// No more lives, game over
					UpdateLives();
					gameplayMessage->SetText("You lose!");
					return true;
				}

				// Pacman got caught, reset lvl
				ResetLevel();
			}
			if (Ghost->CurrentState == Frightened)
			{
				Score += 200; // TODO: Add Multiplier
				Ghost->CurrentState = Eaten;
			}
		}
	}

	// Update Score, Lives and FPS textures
	UpdateScore();
	UpdateLives();
	if (aTime > 0) { SetFPS((float)(1.0f / aTime)); }

	return true;
}

void Pacman::UpdateScore()
{
	std::stringstream stream;
	stream << "Score: " << Score;
	scoreDisplay->SetText(stream.str());
}

void Pacman::UpdateLives()
{
	std::stringstream stream;
	stream << "Lives: ";
	stream << Lives;
	livesDisplay->SetText(stream.str());
}

void Pacman::SetFPS(int fps)
{
	Fps = fps;
	std::string String = "FPS: " + std::to_string(Fps);
	fpsDisplay->SetText(String);
}

bool Pacman::UpdateInput()
{	
	const Uint8 *keystate = SDL_GetKeyboardState(NULL);

	if (keystate[SDL_SCANCODE_UP])
		DesiredDirection = Vector2f(0.f, -1.f);
	else if (keystate[SDL_SCANCODE_DOWN])
		DesiredDirection = Vector2f(0.f, 1.f);
	else if (keystate[SDL_SCANCODE_RIGHT])
		DesiredDirection = Vector2f(1.f, 0.f);
	else if (keystate[SDL_SCANCODE_LEFT])
		DesiredDirection = Vector2f(-1.f, 0.f);

	if (keystate[SDL_SCANCODE_ESCAPE]) { return false; }

	return true;
}

void Pacman::MoveAvatar()
{
	// Check if the desired tile to the input direction is valid, if it is move, 
	// else use the previous moving direction
	int DesiredTileX = myAvatar->GetCurrentTileX() + DesiredDirection.myX;
	int DesiredTileY = myAvatar->GetCurrentTileY() + DesiredDirection.myY;
	if (myWorld->TileIsValid(DesiredTileX, DesiredTileY))
	{
		myNextMovement = DesiredDirection;
	}

	int nextTileX = myAvatar->GetCurrentTileX() + myNextMovement.myX;
	int nextTileY = myAvatar->GetCurrentTileY() + myNextMovement.myY;

	if (myAvatar->IsAtDestination())
	{
		if (myWorld->TileIsValid(nextTileX, nextTileY))
		{
			myAvatar->SetNextTile(nextTileX, nextTileY);
		}
	}
}

bool Pacman::CheckEndGameCondition()
{
	return myWorld->GetDotCount() == 0;
}

bool Pacman::Draw()
{
	std::list<Ghost*>::iterator ghostIterator;
	myWorld->Draw(myDrawer);
	myAvatar->Draw(myDrawer);
	for (ghostIterator = ghosts.begin(); ghostIterator != ghosts.end(); ghostIterator++)
		(*ghostIterator)->Draw(myDrawer);

	scoreDisplay->Draw(myDrawer, 20, 50); 
	livesDisplay->Draw(myDrawer, 20, 80);
	fpsDisplay->Draw(myDrawer, 880, 50);

	if (CheckEndGameCondition() || Lives <= 0)
		gameplayMessage->Draw(myDrawer, 500, 100);

	return true;
}
