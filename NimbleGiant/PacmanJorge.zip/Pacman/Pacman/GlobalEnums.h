#pragma once

enum State
{
	Chase,
	Scatter,
	Frightened,
	Eaten,
	Spawning,
};

enum GhostName
{
	Blinky,
	Pinky,
	Inky,
	Clyde,
};

enum ImageIdentifier
{
	Null_Image = 0,

	Ghost_Normal,
	Ghost_Frightened,
	Ghost_Eaten,

	Game_Background,
	Game_SmallDot,
	Game_BigDot,
	Game_Cherry,

	Avatar_Closed_Right,
	Avatar_Open_Right,
	Avatar_Closed_Down,
	Avatar_Open_Down,
	Avatar_Closed_Left,
	Avatar_Open_Left,
	Avatar_Closed_Up,
	Avatar_Open_Up,
};

enum Direction : int
{
	Up = 0,
	Left = 1,
	Down = 2,
	Right = 3,
	DirectionCount = 4,
};