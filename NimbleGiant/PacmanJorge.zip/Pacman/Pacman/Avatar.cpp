#include "Avatar.h"

Avatar::Avatar(const Vector2f& aPosition, Sprite* entitySprite)
: MovableGameEntity(aPosition, entitySprite)
{
	sprite->SetFrame(Avatar_Open_Left);
	FacingDirection = Left;
	Speed = 120.0f;
}

void Avatar::Update(float aTime)
{
	int tileSize = 22;

	Vector2f destination(myNextTileX * tileSize, myNextTileY * tileSize);
	Vector2f direction = destination - myPosition;

	// Set the pacman sprite direction
	if (direction.myX > 0)
	{
		sprite->SetFrame(Avatar_Open_Right);
		FacingDirection = Right;
	}
	else if (direction.myX < 0)
	{
		sprite->SetFrame(Avatar_Open_Left);
		FacingDirection = Left;
	}
	else if (direction.myY < 0)
	{
		sprite->SetFrame(Avatar_Open_Up);
		FacingDirection = Up;
	}
	else if (direction.myY > 0)
	{
		sprite->SetFrame(Avatar_Open_Down);
		FacingDirection = Down;
	}

	float distanceToMove = aTime * Speed;

	if (distanceToMove > direction.Length())
	{
		myPosition = destination;
		myCurrentTileX = myNextTileX;
		myCurrentTileY = myNextTileY;
	}
	else
	{
		direction.Normalize();
		myPosition += direction * distanceToMove;
	}
}

Direction Avatar::GetFacingDirection()
{
	return FacingDirection;
}
