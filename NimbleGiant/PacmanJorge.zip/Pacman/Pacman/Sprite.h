#ifndef SPRITE_H
#define SPRITE_H

#include <list>
#include <map>
#include <string>
#include "SDL_image.h"
#include "SDL_rect.h"
#include "GlobalEnums.h"

struct SDL_Texture;
class Drawer;

class Sprite
{
public:
	Sprite() {};

	void SetFrame(ImageIdentifier Id);
	void Draw(Drawer* drawer, int posX, int posY);
	void AddTexture(Drawer *drawer, std::string Filename, ImageIdentifier Key);
	void SetSize(int Width, int Height);

private:

	std::map<int, SDL_Texture*> textures;
	int currentFrame;
	SDL_Rect frame {};
};

#endif // SPRITE_H