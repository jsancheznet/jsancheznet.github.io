#ifndef GHOST_H
#define GHOST_H

#include <list>
#include "MovableGameEntity.h"
#include "GlobalEnums.h"
#include "MapTile.h"
#include "Pacman.h"

class World;
class PathmapTile;
class Avatar;
class Pacman;

class Ghost : public MovableGameEntity
{
public:

	enum GhostName
	{
		Blinky,
		Pinky,
		Inky,
		Clyde,
	};

	Ghost(const Vector2f& aPosition, Sprite* entitySprite, GhostName Name);

	void Update(float aTime, World* aWorld, Avatar* avatar, State GlobalState, Pacman* pacman);
	void ChooseNextTile(World *aWorld, int TargetX, int TargetY);
	void ChooseRandomTile(World* aWorld);
	void SetTexture(ImageIdentifier Id);

	GhostName  Name;
	State CurrentState;

protected:
private:
	float Speed;
	const float RegularSpeed = 90.0f;
	const float EatenSpeed = 180.0f;

	void UpdateBlinky(World*, Avatar*, State GlobalState);
	void UpdatePinky(World*, Avatar*, State GlobalState);
	void UpdateInky(World*, Avatar*, State GlobalState, Pacman *pacman);
	void UpdateClyde(World*, Avatar*, State GlobalState);

	void SetCurrentState(State);

	bool  DirectionIsValid(World*, Direction);
	bool  NotPreviousDirection(Direction);
	float DistanceFromAvatar(Avatar*);
};

#endif // GHOST_H