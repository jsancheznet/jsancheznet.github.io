#include "StaticGameEntity.h"

StaticGameEntity::StaticGameEntity(Vector2f aPosition, Sprite* entitySprite)
: GameEntity(aPosition, entitySprite)
{
}