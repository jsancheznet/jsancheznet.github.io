#ifndef WORLD_H
#define WORLD_H

#include <list>
#include <map>
#include <vector>
#include "Vector2f.h"
#include "Sprite.h"
#include "MapTile.h"

class Drawer;
class PathmapTile;
class Dot;
class BigDot;
class Cherry;

class World
{
public:
	World(void)  {};
	~World(void) {};

	void Init(Drawer* gameDrawer);

	void Draw(Drawer* aDrawer);
	bool TileIsValid(int anX, int anY);

	bool HasIntersectedDot(const Vector2f& aPosition);
	bool HasIntersectedBigDot(const Vector2f& aPosition);
	bool HasIntersectedCherry(const Vector2f& aPosition);
	int  GetDotCount();

private:
	bool InitMap(Drawer* gameDrawer);

	std::vector<MapTile> ValidTiles;

	std::list<Dot*>    myDots;
	std::list<BigDot*> myBigDots;
	std::list<Cherry*> myCherry;

	Sprite* DotSprite       = nullptr;
	Sprite* BigDotSprite    = nullptr;
	Sprite* boardBackground = nullptr;
};

#endif // WORLD_H