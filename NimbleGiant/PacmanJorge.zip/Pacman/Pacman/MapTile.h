#ifndef MAPTILE_H
#define MAPTILE_H

class MapTile
{
public:
	MapTile(int anX, int anY);

	int X;
	int Y;
};

#endif // MAPTILE_H
